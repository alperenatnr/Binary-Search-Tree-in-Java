package binarysearchtree;

public class BST {
    Node root;
    
    public void Insert(int value){
        root = Insert(root,value);
    }
    
    Node Insert(Node root,int value){
        Node newNode = new Node(value);
        
        if(root==null){
            root = newNode;
            return root;
        }
        else if(root.value > value){
            root.left = Insert(root.left,value);
        }
        else{
            root.right = Insert(root.right,value);
        }
        return root;
    }
    
    public void inOrder(){
        inOrder(root);       
    }
    
    public void inOrder(Node root){
        if(root!=null){
            inOrder(root.left);
            System.out.println(root.value);
            inOrder(root.right);
        }
    }
    
    public void preOrder(){
        preOrder(root);
        System.out.println();
    }
    public void preOrder(Node root){
        if(root!=null){
            System.out.println(root.value+" ");
            preOrder(root.left);
            preOrder(root.right);
        }
    }
    
    public boolean search(int value) {
        return search(root, value);
    }

    private boolean search(Node root, int value) {
        if (root == null) {
            System.out.println(value + " Not Founded.");
            return false;
        } else if (root.value == value) {
            System.out.println(value + " Found.");
            return true;
        } else if (root.value > value) {
            return search(root.left, value);
        }
        return search(root.right, value);
    }
}
