package binarysearchtree;

import java.util.Scanner;

public class BinarySearchTree {

    public static void main(String[] args) {
       Scanner scan = new Scanner(System.in);
       BST tree = new BST();
       
       int option = -1;
       int num1 = 0;
       
       while(option!=0){
           System.out.println("_____________________");
           System.out.println("                     ");
           System.out.println("Binary Search Tree");
           System.out.println("_____________________");
           System.out.println("Choose an option");
           System.out.println("1. Insert an element");
           System.out.println("2. Preorder Traversal");
           System.out.println("3. Inorder Traversal");
           System.out.println("4. Search an element");
           System.out.println("0.Exit the Program");
           option = scan.nextInt();
           switch(option){
               case 1:
                   System.out.println("Enter a number");
                   num1 = scan.nextInt();
                   tree.Insert(num1);
                   break;
               case 2:
                   tree.preOrder();
                   break;
               case 3:
                   tree.inOrder();
                   break;
               case 4:
                   System.out.println("Which element do you search?");
                   num1 = scan.nextInt();
                   tree.search(num1);
                   break;              
           }
       }
    }
    
}
